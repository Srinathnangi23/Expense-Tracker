from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, extract
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.user import User
from app.models.expense import Expense
from app.models.category import Category
from app.schemas.expense import ExpenseCreate, ExpenseUpdate, ExpenseOut, MonthlySummary

router = APIRouter(prefix="/expenses", tags=["expenses"])


@router.get("/", response_model=list[ExpenseOut])
def list_expenses(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    category_id: Optional[int] = None,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    search: Optional[str] = Query(default=None, description="Search in title/notes"),
    sort_by: str = Query(default="date", pattern="^(date|amount|title)$"),
    order: str = Query(default="desc", pattern="^(asc|desc)$"),
    skip: int = 0,
    limit: int = 100,
):
    q = db.query(Expense).filter(Expense.owner_id == current_user.id)

    if category_id is not None:
        q = q.filter(Expense.category_id == category_id)
    if start_date is not None:
        q = q.filter(Expense.date >= start_date)
    if end_date is not None:
        q = q.filter(Expense.date <= end_date)
    if search:
        like = f"%{search}%"
        q = q.filter((Expense.title.ilike(like)) | (Expense.notes.ilike(like)))

    sort_col = getattr(Expense, sort_by)
    q = q.order_by(sort_col.asc() if order == "asc" else sort_col.desc())

    return q.offset(skip).limit(limit).all()


@router.post("/", response_model=ExpenseOut, status_code=status.HTTP_201_CREATED)
def create_expense(
    expense_in: ExpenseCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if expense_in.category_id is not None:
        category = (
            db.query(Category)
            .filter(Category.id == expense_in.category_id, Category.owner_id == current_user.id)
            .first()
        )
        if not category:
            raise HTTPException(status_code=404, detail="Category not found")

    expense = Expense(**expense_in.model_dump(), owner_id=current_user.id)
    db.add(expense)
    db.commit()
    db.refresh(expense)
    return expense


def _get_owned_expense(expense_id: int, db: Session, current_user: User) -> Expense:
    expense = (
        db.query(Expense)
        .filter(Expense.id == expense_id, Expense.owner_id == current_user.id)
        .first()
    )
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    return expense


@router.get("/summary/monthly", response_model=MonthlySummary)
def monthly_summary(
    year: int,
    month: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    rows = (
        db.query(Category.name, func.sum(Expense.amount))
        .join(Category, Expense.category_id == Category.id, isouter=True)
        .filter(
            Expense.owner_id == current_user.id,
            extract("year", Expense.date) == year,
            extract("month", Expense.date) == month,
        )
        .group_by(Category.name)
        .all()
    )

    by_category = {(name or "Uncategorized"): float(total) for name, total in rows}
    total = sum(by_category.values())

    return MonthlySummary(year=year, month=month, total=total, by_category=by_category)


@router.get("/{expense_id}", response_model=ExpenseOut)
def get_expense(
    expense_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _get_owned_expense(expense_id, db, current_user)


@router.put("/{expense_id}", response_model=ExpenseOut)
def update_expense(
    expense_id: int,
    expense_in: ExpenseUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    expense = _get_owned_expense(expense_id, db, current_user)

    update_data = expense_in.model_dump(exclude_unset=True)
    if "category_id" in update_data and update_data["category_id"] is not None:
        category = (
            db.query(Category)
            .filter(
                Category.id == update_data["category_id"], Category.owner_id == current_user.id
            )
            .first()
        )
        if not category:
            raise HTTPException(status_code=404, detail="Category not found")

    for field, value in update_data.items():
        setattr(expense, field, value)

    db.commit()
    db.refresh(expense)
    return expense


@router.delete("/{expense_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_expense(
    expense_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    expense = _get_owned_expense(expense_id, db, current_user)
    db.delete(expense)
    db.commit()
