from datetime import date, datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field

from app.schemas.category import CategoryOut


class ExpenseCreate(BaseModel):
    title: str
    amount: float = Field(gt=0)
    date: date
    notes: Optional[str] = None
    category_id: Optional[int] = None


class ExpenseUpdate(BaseModel):
    title: Optional[str] = None
    amount: Optional[float] = Field(default=None, gt=0)
    date: Optional[date] = None
    notes: Optional[str] = None
    category_id: Optional[int] = None


class ExpenseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    amount: float
    date: date
    notes: Optional[str] = None
    category_id: Optional[int] = None
    category: Optional[CategoryOut] = None
    created_at: datetime
    updated_at: datetime


class MonthlySummary(BaseModel):
    year: int
    month: int
    total: float
    by_category: dict[str, float]
